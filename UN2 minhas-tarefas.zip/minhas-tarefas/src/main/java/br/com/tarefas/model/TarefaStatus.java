package br.com.tarefas.model;

public enum TarefaStatus {

	ABERTO, EM_ANDAMENTO, CONCLUIDA, CANCELADA
}
